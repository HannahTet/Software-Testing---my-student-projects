let time = 7200;
const countDownEl = document.getElementById("countdown");

setInterval(updateCountdown, 1000);

function updateCountdown() {
    const hours = Math.floor(time / 3600);
    const minutes = Math.floor(time / 120); 
    let seconds = time % 60; // devide seconds without remain
    seconds = seconds < 10 ? "0" + seconds: //add 0 to seconds less than 10
    seconds;
    countDownEl.innerHTML = `${hours}:${minutes}:${seconds}`;
    time--;
};